
ALTER TABLE `engine4_poll_polls`
  CHANGE COLUMN `views` `view_count` int(11) unsigned NOT NULL default '0' ;
