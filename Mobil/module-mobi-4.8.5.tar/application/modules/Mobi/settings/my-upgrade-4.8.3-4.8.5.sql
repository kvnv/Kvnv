INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `order`) VALUES
('mobi_profile_message', 'mobi', 'Send Message', 'Mobi_Plugin_Menus', '', 'mobi_profile', '', 1),
('mobi_profile_friend', 'mobi', 'Friends', 'Mobi_Plugin_Menus', '', 'mobi_profile', '', 2),
('mobi_profile_edit', 'mobi', 'Edit Profile', 'Mobi_Plugin_Menus', '', 'mobi_profile', '', 3),
('mobi_profile_report', 'mobi', 'Report User', 'Mobi_Plugin_Menus', '', 'mobi_profile', '', 4),
('mobi_profile_block', 'mobi', 'Block', 'Mobi_Plugin_Menus', '', 'mobi_profile', '', 5),
('mobi_profile_admin', 'mobi', 'Admin', 'Mobi_Plugin_Menus', '', 'mobi_profile', '', 6);


