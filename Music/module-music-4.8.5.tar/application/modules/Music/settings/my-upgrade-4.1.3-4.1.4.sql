
INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `order`) VALUES
('mobi_browse_music', 'music', 'Music', '', '{"route":"music_general","action":"browse"}', 'mobi_browse', '', 10);
