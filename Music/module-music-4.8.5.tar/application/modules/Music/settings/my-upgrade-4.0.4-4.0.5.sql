
/* This query was removed for changes in 4.1.0 */
/*
INSERT IGNORE INTO `engine4_core_tasks` (`title`, `module`, `plugin`, `timeout`, `priority`) VALUES
('Music Cleanup', 'music', 'Music_Plugin_Task_Maintenance_Cleanup', 900, 20);
*/
