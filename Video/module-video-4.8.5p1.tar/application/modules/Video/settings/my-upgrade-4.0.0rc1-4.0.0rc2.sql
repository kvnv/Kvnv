
/* This query was removed for changes in 4.1.0 */
/*
UPDATE `engine4_core_tasks`
SET title = 'Background Video Encoder'
WHERE plugin = 'Video_Plugin_Task_Encode';
*/
