UPDATE `engine4_activity_notificationtypes` SET `body` = 'Your request to join the group {item:$object} has been approved.' WHERE `type` = 'group_accepted';
