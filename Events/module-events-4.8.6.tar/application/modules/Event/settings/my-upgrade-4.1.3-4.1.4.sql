
INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `order`) VALUES
('mobi_browse_event', 'event', 'Events', '', '{"route":"event_general"}', 'mobi_browse', '', 7);