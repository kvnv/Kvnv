
INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `order`) VALUES
('event_profile_delete', 'event', 'Delete Event', 'Event_Plugin_Menus', '', 'event_profile', '', 8);
