
INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `order`) VALUES
('authorization_admin_level_chat', 'chat', 'Chat', '', '{"route":"admin_default","module":"chat","controller":"settings","action":"level"}', 'authorization_admin_level', '', 999)
;
