
DELETE FROM `engine4_core_search` WHERE `type` = 'activity_action';
DELETE FROM `engine4_core_search` WHERE `type` = 'activity_notification';
