
ALTER TABLE `engine4_activity_comments`
  ADD COLUMN `like_count` int(11) unsigned NOT NULL default '0' ;
