
ALTER TABLE `engine4_payment_packages` ADD COLUMN `default` tinyint(1) unsigned NOT NULL default '0' ;
