
INSERT IGNORE INTO `engine4_payment_gateways` (`title`, `description`, `enabled`, `plugin`, `test_mode`) VALUES
('Testing', NULL, 0, 'Payment_Plugin_Gateway_Testing', 1);
