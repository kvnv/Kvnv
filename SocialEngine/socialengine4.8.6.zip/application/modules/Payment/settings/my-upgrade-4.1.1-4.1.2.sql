
/* Fix some incorrect default collations */
ALTER TABLE `engine4_payment_products` DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci ;
