ALTER TABLE `engine4_payment_packages` ADD COLUMN `after_signup` tinyint(1) unsigned NOT NULL default '1' ;
