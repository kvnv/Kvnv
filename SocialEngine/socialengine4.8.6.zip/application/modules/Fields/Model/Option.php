<?php
/**
 * SocialEngine
 *
 * @category   Application_Core
 * @package    Fields
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: Option.php 9747 2012-07-26 02:08:08Z john $
 * @author     John
 */

/**
 * @category   Application_Core
 * @package    Fields
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @author     John
 */
class Fields_Model_Option extends Fields_Model_Abstract
{
  public function getFields()
  {
    return Engine_Api::_()->fields()
      ->getFieldsMeta($this->_type)
      ->getRowsMatching('parent_option_id', $this->option_id);
  }
}