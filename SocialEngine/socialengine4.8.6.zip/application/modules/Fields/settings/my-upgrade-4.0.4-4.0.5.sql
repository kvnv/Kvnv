
DELETE FROM `engine4_activity_actiontypes`
WHERE `type` = 'fields_change_generic' ;
