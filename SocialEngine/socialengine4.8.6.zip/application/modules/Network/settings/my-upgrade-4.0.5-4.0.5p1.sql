
DELETE FROM `engine4_core_search` WHERE `type` = 'network';
