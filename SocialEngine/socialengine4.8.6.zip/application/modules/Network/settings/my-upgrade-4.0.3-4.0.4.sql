
/* This query was removed for changes in 4.1.0 */
/*
INSERT IGNORE INTO `engine4_core_tasks` (`title`, `category`, `module`, `plugin`, `timeout`, `type`) VALUES
('Rebuild Network Membership', 'maintenance', 'network', 'Network_Plugin_Task_Maintenance_RebuildMembership', 0, 'semi-automatic');
*/
